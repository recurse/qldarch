This software is copyright Aduna (http://www.aduna-software.com/) � 2001-2011.
Licensed under the Aduna BSD-style license.

For the full text of the license, see the file LICENSE.txt.

By using, modifying or distributing this software you agree to be bound by the
terms of this license.

This software may include 3rd-party components that are licensed under
different conditions. For details see the file NOTICE.txt.
