java -cp bin/Euler.jar:bin/Euler_Tests.jar euler.EulerRunner $*
