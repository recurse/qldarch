#!/usr/bin/env python

__version__ = '$Id: codd.py 1295 2007-05-11 16:52:51Z josd $'

import BaseHTTPServer, cgi, swap.cwm, euler, sys, time, urllib

class codd(BaseHTTPServer.BaseHTTPRequestHandler):
    server_version = 'codd/' + __version__[1:-1]
    def do_GET(self):
        try: f, q = self.path.split('?', 1)
        except ValueError: f, q = self.path, ''
        args = cgi.parse_qs(q)
        ct = 'text/plain'
        r = ''
        try:
            if f == '/.cwm':
                x1 = sys.argv
                x2 = sys.stdout
                sys.argv[1:] = args.get('ARG', [''])[0].split()
                t = tee('')
                sys.stdout = t
                ts = time.time()
                swap.cwm.doCommand()
                sys.stdout.write('# Elapsed time: %s sec\n' % (time.time()-ts))
                r = t.sink
                sys.stdout = x2
                sys.argv = x1
            elif f == '/.euler':
                x1 = sys.argv
                x2 = sys.stdout
                sys.argv[1:] = args.get('ARG', [''])[0].split()
                t = tee('')
                sys.stdout = t
                ts = time.time()
                euler.run(sys.argv[1:])
                sys.stdout.write('# Elapsed time: %s sec\n' % (time.time()-ts))
                r = t.sink
                sys.stdout = x2
                sys.argv = x1
            else: r = self.server_version
        except:
            self.send_response(400)
            r = str(sys.exc_info()[1])
            self.send_header('Server: ', self.server_version)
            self.send_header('Content-type', 'text/plain')
            self.send_header('Content-Length', str(len(r)))
            self.end_headers()
            self.wfile.write(r)
        else:
            r = r.encode('utf_8')
            self.send_response(200)
            self.send_header('Server: ', self.server_version)
            self.send_header('Content-type', ct)
            self.send_header('Content-Length', str(len(r)))
            self.end_headers()
            self.wfile.write(r)
    do_POST = do_GET

class tee:
    def __init__(self, s):
        self.sink = s
    def write(self, s):
        self.sink = self.sink+s
        sys.__stdout__.write(s)

if __name__ == '__main__':
    try:
        import psyco
        if str(sys.modules['__main__']).find('profile.py') == -1: psyco.full()
    except ImportError: pass
    port = 8000
    for arg in sys.argv[1:]:
        if arg[:2] == '--': arg = arg[1:]
        if arg[:6] == '-port=': port = int(arg[6:])
    sys.stderr.write('%s [port=%d]\n' % (codd.server_version, port))
    BaseHTTPServer.HTTPServer(('', port), codd).serve_forever()
