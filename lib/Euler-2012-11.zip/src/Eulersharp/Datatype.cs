// $Id: Datatype.cs 1295 2007-05-11 16:52:51Z josd $

namespace Eulersharp {

using System;
using System.Collections;
using System.Globalization;
using System.Xml;
using Eulersharp.Output;

/// <summary>XSD support</summary>

public class Datatype {

  internal static Hashtable num = null;
  internal static Hashtable anum = null;

  internal static bool IsNumeric(String dt) {
    if (num == null) {
      num = new Hashtable();
      num[Euler.XSDbyte] = new Object();
      num[Euler.XSDdecimal] = new Object();
      num[Euler.XSDdouble] = new Object();
      num[Euler.XSDfloat] = new Object();
      num[Euler.XSDint] = new Object();
      num[Euler.XSDinteger] = new Object();
      num[Euler.XSDlong] = new Object();
      num[Euler.XSDnegativeInteger] = new Object();
      num[Euler.XSDnonNegativeInteger] = new Object();
      num[Euler.XSDnonPositiveInteger] = new Object();
      num[Euler.XSDpositiveInteger] = new Object();
      num[Euler.XSDshort] = new Object();
      num[Euler.XSDunsignedByte] = new Object();
      num[Euler.XSDunsignedInt] = new Object();
      num[Euler.XSDunsignedLong] = new Object();
      num[Euler.XSDunsignedShort] = new Object();
      num[Euler.MATHabsoluteValue] = new Object();
      num[Euler.MATHatan2] = new Object();
      num[Euler.MATHcos] = new Object();
      num[Euler.MATHcosh] = new Object();
      num[Euler.MATHdegrees] = new Object();
      num[Euler.MATHdifference] = new Object();
      num[Euler.MATHequalTo] = new Object();
      num[Euler.MATHexponentiation] = new Object();
      num[Euler.MATHgreaterThan] = new Object();
      num[Euler.MATHintegerQuotient] = new Object();
      num[Euler.MATHlessThan] = new Object();
      num[Euler.MATHmemberCount] = new Object();
      num[Euler.MATHnegation] = new Object();
      num[Euler.MATHnotEqualTo] = new Object();
      num[Euler.MATHnotGreaterThan] = new Object();
      num[Euler.MATHnotLessThan] = new Object();
      num[Euler.MATHproduct] = new Object();
      num[Euler.MATHproofCount] = new Object();
      num[Euler.MATHquotient] = new Object();
      num[Euler.MATHremainder] = new Object();
      num[Euler.MATHrounded] = new Object();
      num[Euler.MATHsin] = new Object();
      num[Euler.MATHsinh] = new Object();
      num[Euler.MATHsum] = new Object();
      num[Euler.MATHtan] = new Object();
      num[Euler.MATHtanh] = new Object();
    }
    return num[dt] != null;
  }

  internal static bool IsAlphaNumeric(String dt) {
    if (anum == null) {
      anum = new Hashtable();
      anum[Euler.XSDID] = new Object();
      anum[Euler.XSDIDREF] = new Object();
      anum[Euler.XSDNCName] = new Object();
      anum[Euler.XSDNMTOKEN] = new Object();
      anum[Euler.XSDanyURI] = new Object();
      anum[Euler.XSDName] = new Object();
      anum[Euler.XSDlanguage] = new Object();
      anum[Euler.XSDnormalizedString] = new Object();
      anum[Euler.XSDstring] = new Object();
      anum[Euler.XSDtoken] = new Object();
    }
    return anum[dt] != null;
  }

  internal static int Compare(String dt1, String s1, String dt2, String s2) {
    String dt = dt1;
    if (IsNumeric(dt1) && IsNumeric(dt2) && dt1 != dt2) dt = Euler.XSDdouble;
    if (IsAlphaNumeric(dt1) && IsAlphaNumeric(dt2) && dt1 != dt2) dt = Euler.XSDstring;
    try {
      if (dt == Euler.XSDID) return s1.CompareTo(s2);
      if (dt == Euler.XSDIDREF) return s1.CompareTo(s2);
      if (dt == Euler.XSDNCName) return s1.CompareTo(s2);
      if (dt == Euler.XSDNMTOKEN) return s1.CompareTo(s2);
      if (dt == Euler.XSDName) return s1.CompareTo(s2);
      if (dt == Euler.XSDanyURI) return new Uri(s1).ToString().CompareTo(new Uri(s2).ToString());
      if (dt == Euler.XSDbase64Binary) return s1.CompareTo(s2);
      if (dt == Euler.XSDboolean) return XmlConvert.ToBoolean(s1).CompareTo(XmlConvert.ToBoolean(s2));
      if (dt == Euler.XSDbyte) return XmlConvert.ToSByte(s1).CompareTo(XmlConvert.ToSByte(s2));
      if (dt == Euler.XSDdate) return XmlConvert.ToDateTime(s1).CompareTo(XmlConvert.ToDateTime(s2));
      if (dt == Euler.XSDdateTime) return XmlConvert.ToDateTime(s1).CompareTo(XmlConvert.ToDateTime(s2));
      if (dt == Euler.XSDdecimal) return XmlConvert.ToDecimal(s1).CompareTo(XmlConvert.ToDecimal(s2));
      if (dt == Euler.XSDdouble) return XmlConvert.ToDouble(s1).CompareTo(XmlConvert.ToDouble(s2));
      if (dt == Euler.XSDduration) return XmlConvert.ToTimeSpan(s1).CompareTo(XmlConvert.ToTimeSpan(s2));
      if (dt == Euler.XSDfloat) return XmlConvert.ToSingle(s1).CompareTo(XmlConvert.ToSingle(s2));
      if (dt == Euler.XSDgDay) return XmlConvert.ToDateTime(s1).CompareTo(XmlConvert.ToDateTime(s2));
      if (dt == Euler.XSDgMonth) return XmlConvert.ToDateTime(s1).CompareTo(XmlConvert.ToDateTime(s2));
      if (dt == Euler.XSDgMonthDay) return XmlConvert.ToDateTime(s1).CompareTo(XmlConvert.ToDateTime(s2));
      if (dt == Euler.XSDgYear) return XmlConvert.ToDateTime(s1).CompareTo(XmlConvert.ToDateTime(s2));
      if (dt == Euler.XSDgYearMonth) return XmlConvert.ToDateTime(s1).CompareTo(XmlConvert.ToDateTime(s2));
      if (dt == Euler.XSDhexBinary) return s1.CompareTo(s2);
      if (dt == Euler.XSDint) return XmlConvert.ToInt32(s1).CompareTo(XmlConvert.ToInt32(s2));
      if (dt == Euler.XSDinteger) return ToInteger(s1).CompareTo(ToInteger(s2));
      if (dt == Euler.XSDlanguage) return s1.CompareTo(s2);
      if (dt == Euler.XSDlong) return XmlConvert.ToInt64(s1).CompareTo(XmlConvert.ToInt64(s2));
      if (dt == Euler.XSDnegativeInteger) return ToInteger(s1).CompareTo(ToInteger(s2));
      if (dt == Euler.XSDnonNegativeInteger) return ToInteger(s1).CompareTo(ToInteger(s2));
      if (dt == Euler.XSDnonPositiveInteger) return ToInteger(s1).CompareTo(ToInteger(s2));
      if (dt == Euler.XSDnormalizedString) return s1.CompareTo(s2);
      if (dt == Euler.XSDpositiveInteger) return ToInteger(s1).CompareTo(ToInteger(s2));
      if (dt == Euler.XSDshort) return XmlConvert.ToInt16(s1).CompareTo(XmlConvert.ToInt16(s2));
      if (dt == Euler.XSDstring) return s1.CompareTo(s2);
      if (dt == Euler.XSDtime) return XmlConvert.ToDateTime(s1).CompareTo(XmlConvert.ToDateTime(s2));
      if (dt == Euler.XSDtoken) return s1.CompareTo(s2);
      if (dt == Euler.XSDunsignedByte) return XmlConvert.ToByte(s1).CompareTo(XmlConvert.ToByte(s2));
      if (dt == Euler.XSDunsignedInt) return XmlConvert.ToUInt32(s1).CompareTo(XmlConvert.ToUInt32(s2));
      if (dt == Euler.XSDunsignedLong) return XmlConvert.ToUInt64(s1).CompareTo(XmlConvert.ToUInt64(s2));
      if (dt == Euler.XSDunsignedShort) return XmlConvert.ToUInt16(s1).CompareTo(XmlConvert.ToUInt16(s2));
      return s1.CompareTo(s2);
    }
    catch (Exception e) {
      if (Outputter.log) Outputter.GetInstance().Log("DataType", "Compare", "** " + s1 + " or " + s2 + " " + e.Message, Outputter.LOGLEVEL.FINER);
      return s1.CompareTo(s2);
    }
  }

  internal static bool Clash(String dt, String s) {
    if (s.StartsWith("\"\"\"")) return false;
    s = s.Substring(1, s.Length - 2);
    try {
      if (dt == Euler.RDFXMLLiteral) {
        XmlTextReader xr = new XmlTextReader(s, XmlNodeType.Element, null);
        while (xr.Read());
        xr.Close();
        return false;
      }
      if (dt == Euler.XSDID) return s == null;
      if (dt == Euler.XSDIDREF) return s == null;
      if (dt == Euler.XSDNCName) return s == null;
      if (dt == Euler.XSDNMTOKEN) return s == null;
      if (dt == Euler.XSDName) return s == null;
      if (dt == Euler.XSDanyURI) return new Uri(s) == null;
      if (dt == Euler.XSDbase64Binary) return s == null;
      if (dt == Euler.XSDboolean) return XmlConvert.ToBoolean(s).Equals(null);
      if (dt == Euler.XSDbyte) return XmlConvert.ToSByte(s).Equals(null);
      if (dt == Euler.XSDdate) return XmlConvert.ToDateTime(s).Equals(null);
      if (dt == Euler.XSDdateTime) return XmlConvert.ToDateTime(s).Equals(null);
      if (dt == Euler.XSDdecimal) return XmlConvert.ToDecimal(s).Equals(null);
      if (dt == Euler.XSDdouble) return XmlConvert.ToDouble(s).Equals(null);
      if (dt == Euler.XSDduration) return XmlConvert.ToTimeSpan(s).Equals(null);
      if (dt == Euler.XSDfloat) return XmlConvert.ToSingle(s).Equals(null);
      if (dt == Euler.XSDgDay) return XmlConvert.ToDateTime(s).Equals(null);
      if (dt == Euler.XSDgMonth) return XmlConvert.ToDateTime(s).Equals(null);
      if (dt == Euler.XSDgMonthDay) return XmlConvert.ToDateTime(s).Equals(null);
      if (dt == Euler.XSDgYear) return XmlConvert.ToDateTime(s).Equals(null);
      if (dt == Euler.XSDgYearMonth) return XmlConvert.ToDateTime(s).Equals(null);
      if (dt == Euler.XSDhexBinary) return s == null;
      if (dt == Euler.XSDint) return XmlConvert.ToInt32(s).Equals(null);
      if (dt == Euler.XSDinteger) return ToInteger(s).Equals(null);
      if (dt == Euler.XSDlanguage) return s == null;
      if (dt == Euler.XSDlong) return XmlConvert.ToInt64(s).Equals(null);
      if (dt == Euler.XSDnegativeInteger) return ToInteger(s).Equals(null) || ToInteger(s).CompareTo(ToInteger("0")) >= 0;
      if (dt == Euler.XSDnonNegativeInteger) return ToInteger(s).Equals(null) || ToInteger(s).CompareTo(ToInteger("0")) < 0;
      if (dt == Euler.XSDnonPositiveInteger) return ToInteger(s).Equals(null) || ToInteger(s).CompareTo(ToInteger("0")) > 0;
      if (dt == Euler.XSDnormalizedString) return s == null;
      if (dt == Euler.XSDpositiveInteger) return ToInteger(s).Equals(null) || ToInteger(s).CompareTo(ToInteger("0")) <= 0;
      if (dt == Euler.XSDshort) return XmlConvert.ToInt16(s).Equals(null);
      if (dt == Euler.XSDstring) return s == null;
      if (dt == Euler.XSDtime) return XmlConvert.ToDateTime(s).Equals(null);
      if (dt == Euler.XSDtoken) return s == null;
      if (dt == Euler.XSDunsignedByte) return XmlConvert.ToByte(s).Equals(null);
      if (dt == Euler.XSDunsignedInt) return XmlConvert.ToUInt32(s).Equals(null);
      if (dt == Euler.XSDunsignedLong) return XmlConvert.ToUInt64(s).Equals(null);
      if (dt == Euler.XSDunsignedShort) return XmlConvert.ToUInt16(s).Equals(null);
      return true;
    }
    catch (Exception e) {
      if (Outputter.log) Outputter.GetInstance().Log("DataType", "Clash", "** " + s + ": " + e.Message, Outputter.LOGLEVEL.FINER);
      return true;
    }
  }

  internal static Decimal ToInteger(string s) {
    return Decimal.Parse(s, NumberStyles.AllowLeadingSign|NumberStyles.AllowLeadingWhite|NumberStyles.AllowTrailingWhite, NumberFormatInfo.InvariantInfo);
  }
}
}
