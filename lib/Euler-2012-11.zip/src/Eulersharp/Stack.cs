// $Id: Stack.cs 1295 2007-05-11 16:52:51Z josd $

namespace Eulersharp {

using System;

/// <summary>
/// Euler specific stack class.
/// </summary>
public class Stack {
  internal int max = 4096;
  internal int top = 0;
  internal Euler[] ea;
  internal int[] ia;
  internal Euler w;
  
  /// <summary>
  /// This method constructs an instance of the stack class.
  /// </summary>
  public Stack() {
    ea = new Euler[max];
    ia = new int[max];
    w = new Euler();
  }

  internal void push(Euler e, int i) {
    ea[top] = e;
    ia[top++] = i;
    if (top == max) {
      Euler[] ea_ = ea;
      int[] ia_ = ia;
      int max_ = max;
      max = max * 2;
      ea = new Euler[max];
      ia = new int[max];
      Array.Copy(ea_, 0, ea, 0, max_);
      Array.Copy(ia_, 0, ia, 0, max_);
    }
  }
  
  internal Euler pop() {
    if (top == 0)
      return null;
    if (ea[--top] == null) {
      w.varid = ia[top];
      return w;
    }
    else
      return ea[top];
  }
}
}
