// $Id: ConsistencyTest_ETC2.cs 1295 2007-05-11 16:52:51Z josd $

namespace Eulersharp.test 
{

  using System;
  using System.IO;
  using System.Reflection;

  /// <summary>
  /// Class to test the euler engine
  /// </summary>
  [NUnit.Framework.TestFixture]
  public class ConsistencyTest_ETC2
  {

    /// <summary>
    /// Code to set up the test
    /// </summary>
    [NUnit.Framework.SetUp]
    public void Init() 
    {
      Outputter.getInstance().initialize("etc2-results-net.n3");
    }

    /// <summary>
    /// Code to shut down the test
    /// </summary>
    [NUnit.Framework.TearDown]
    public void TearDown()
    {
      File.Delete("test.n3");
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void AnnotationProperty_003() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[0], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void AnnotationProperty_004() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[1], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void DatatypeProperty_001() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[2], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_1_010() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[3], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_2_001() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[4], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_2_003() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[5], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_2_005() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[6], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_2_010() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[7], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_2_011() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[8], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_26_001() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[9], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_26_002() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[10], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_26_003() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[11], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_26_004() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[12], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_26_005() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[13], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_26_006() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[14], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_26_007() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[15], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_3_005() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[16], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_3_006() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[17], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_3_007() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[18], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_3_008() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[19], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_3_009() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[20], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_3_010() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[21], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_3_011() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[22], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_002() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[23], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_012() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[24], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_013() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[25], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_014() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[26], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_015() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[27], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_016() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[28], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I6_1_001() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[29], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Restriction_003() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[30], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Restriction_004() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[31], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Thing_004() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[32], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void backwardCompatibleWith_001() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[33], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void backwardCompatibleWith_002() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[34], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_005() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[35], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_006() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[36], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_009() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[37], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_016() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[38], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_018() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[39], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_020() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[40], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_021() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[41], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_024() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[42], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_025() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[43], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_028() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[44], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_031() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[45], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_034() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[46], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_501() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[47], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_503() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[48], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_605() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[49], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_606() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[50], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_609() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[51], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_616() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[52], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_624() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[53], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_625() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[54], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_628() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[55], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_631() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[56], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_634() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[57], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_905() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[58], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_906() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[59], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_907() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[60], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_908() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[61], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void disjointWith_003() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[62], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void disjointWith_004() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[63], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void disjointWith_005() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[64], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void disjointWith_006() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[65], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void disjointWith_007() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[66], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void disjointWith_008() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[67], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void disjointWith_009() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[68], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void equivalentClass_009() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[69], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void imports_012() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[70], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void miscellaneous_001() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[71], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void miscellaneous_002() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[72], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void miscellaneous_102() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[73], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void miscellaneous_103() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[74], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void miscellaneous_201() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[75], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void miscellaneous_202() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[76], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void miscellaneous_205() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[77], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void miscellaneous_303() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[78], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void oneOf_001() 
    {
      Data.executeTest(Data.ConsistencyTests_etc2[79], "etc2-results-net.n3", "ConsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

  }
}
