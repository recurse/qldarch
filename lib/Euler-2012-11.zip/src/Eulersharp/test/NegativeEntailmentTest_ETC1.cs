// $Id: NegativeEntailmentTest_ETC1.cs 1295 2007-05-11 16:52:51Z josd $

namespace Eulersharp.test 
{

  using System;
  using System.IO;
  using System.Reflection;

  /// <summary>
  /// Class to test the euler engine
  /// </summary>
  [NUnit.Framework.TestFixture]
  public class NegativeEntailmentTest_ETC1
  {

    /// <summary>
    /// Code to set up the test
    /// </summary>
    [NUnit.Framework.SetUp]
    public void Init() 
    {
      Outputter.getInstance().initialize("etc1-results-net.n3");
    }

    /// <summary>
    /// Code to shut down the test
    /// </summary>
    [NUnit.Framework.TearDown]
    public void TearDown()
    {
      File.Delete("test.n3");
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void rdftests_rdfcore_datatypesintensional_xsdintegerdecimalcompatible() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[0], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_datatypes_nonwellformedliteral2() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[1], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void rdftests_rdfcore_datatypes_test009() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[2], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_horst01_subClassOfintensional() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[3], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_horst01_subPropertyOfintensional() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[4], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_rdfcharmoduris_test003() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[5], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_rdfcharmoduris_test004() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[6], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_rdfmsxmllang_test007a() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[7], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_rdfmsxmllang_test007b() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[8], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_rdfmsxmllang_test007c() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[9], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void rdftests_rdfcore_rdfscontainermembershipsuperProperty_test001() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[10], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void rdftests_rdfcore_rdfsdomainandrange_intensionalitydomain() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[11], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void rdftests_rdfcore_rdfsdomainandrange_intensionalityrange() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[12], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_rdfssubClassOfaProperty_test001() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[13], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_statemententailment_test001() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[14], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_statemententailment_test002() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[15], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_statemententailment_test003() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[16], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_statemententailment_test004() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[17], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_xmlsch02_whitespacefacet1() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[18], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_xmlsch02_whitespacefacet2() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[19], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_xmlsch02_whitespacefacet4() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc1[20], "etc1-results-net.n3", "NegativeEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

  }
}
