// $Id: PositiveEntailmentTest_ETC1.cs 1295 2007-05-11 16:52:51Z josd $

namespace Eulersharp.test 
{

  using System;
  using System.IO;
  using System.Reflection;

  /// <summary>
  /// Class to test the euler engine
  /// </summary>
  [NUnit.Framework.TestFixture]
  public class PositiveEntailmentTest_ETC1
  {

    /// <summary>
    /// Code to set up the test
    /// </summary>
    [NUnit.Framework.SetUp]
    public void Init() 
    {
      Outputter.getInstance().initialize("etc1-results-net.n3");
    }

    /// <summary>
    /// Code to shut down the test
    /// </summary>
    [NUnit.Framework.TearDown]
    public void TearDown()
    {
      File.Delete("test.n3");
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void rdftests_rdfcore_datatypesintensional_xsdintegerstringincompatible() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[0], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_datatypes_nonwellformedliteral1() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[1], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_datatypes_plainliteralandxsdstring() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[2], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void rdftests_rdfcore_datatypes_rangeclash() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[3], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void rdftests_rdfcore_datatypes_semanticequivalencebetweendatatypes() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[4], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void rdftests_rdfcore_datatypes_semanticequivalencewithintype1() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[5], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void rdftests_rdfcore_datatypes_semanticequivalencewithintype2() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[6], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void rdftests_rdfcore_datatypes_test008() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[7], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void rdftests_rdfcore_datatypes_test010() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[8], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_pfps10_nonwellformedliteral1() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[9], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_rdfmsseqrepresentation_test002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[10], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_rdfmsseqrepresentation_test003() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[11], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_rdfmsseqrepresentation_test004() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[12], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_rdfsentailment_test001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[13], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_rdfsentailment_test002() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[14], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_rdfsnocyclesinsubClassOf_test001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[15], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_rdfsnocyclesinsubPropertyOf_test001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[16], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_rdfssubPropertyOfsemantics_test001() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[17], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_tex01_languagetagcase1() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[18], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_tex01_languagetagcase2() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[19], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void
      rdftests_rdfcore_xmlsch02_whitespacefacet3() 
    {
      Data.executeTest(Data.PositiveEntailmentTests_etc1[20], "etc1-results-net.n3", "PositiveEntailmentTest_ETC1_" + MethodBase.GetCurrentMethod().Name);
    }

  }
}
