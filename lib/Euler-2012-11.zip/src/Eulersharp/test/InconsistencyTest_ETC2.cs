// $Id: InconsistencyTest_ETC2.cs 1295 2007-05-11 16:52:51Z josd $

namespace Eulersharp.test 
{

  using System;
  using System.IO;
  using System.Reflection;

  /// <summary>
  /// Class to test the euler engine
  /// </summary>
  [NUnit.Framework.TestFixture]
  public class InconsistencyTest_ETC2
  {

    /// <summary>
    /// Code to set up the test
    /// </summary>
    [NUnit.Framework.SetUp]
    public void Init() 
    {
      Outputter.getInstance().initialize("etc2-results-net.n3");
    }

    /// <summary>
    /// Code to shut down the test
    /// </summary>
    [NUnit.Framework.TearDown]
    public void TearDown()
    {
      File.Delete("test.n3");
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I4_5_002() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[0], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_5_003() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[1], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_5_004() 
  {
      Data.executeTest(Data.InconsistencyTests_etc2[2], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_001() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[3], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_003() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[4], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Nothing_001() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[5], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Restriction_001() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[6], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Restriction_002() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[7], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Thing_003() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[8], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Thing_005() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[9], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_001() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[10], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_002() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[11], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_003() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[12], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_004() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[13], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_007() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[14], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_008() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[15], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_010() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[16], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_011() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[17], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_012() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[18], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_013() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[19], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_014() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[20], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_015() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[21], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_017() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[22], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_019() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[23], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_022() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[24], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_023() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[25], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_026() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[26], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_027() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[27], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_029() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[28], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_030() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[29], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_032() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[30], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_033() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[31], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_035() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[32], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_040() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[33], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_101() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[34], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_102() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[35], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_103() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[36], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_104() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[37], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_105() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[38], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_106() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[39], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_107() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[40], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_108() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[41], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_109() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[42], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_110() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[43], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_111() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[44], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_502() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[45], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_504() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[46], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_601() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[47], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_602() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[48], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_603() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[49], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_604() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[50], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_608() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[51], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_610() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[52], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_611() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[53], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_612() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[54], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_613() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[55], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_614() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[56], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_615() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[57], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_617() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[58], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_623() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[59], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_626() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[60], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_627() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[61], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_629() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[62], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_630() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[63], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_632() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[64], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_633() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[65], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_641() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[66], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_642() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[67], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_643() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[68], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_644() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[69], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_646() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[70], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_650() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[71], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_909() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[72], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_910() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[73], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void disjointWith_010() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[74], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void maxCardinality_001() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[75], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void maxCardinality_002() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[76], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void miscellaneous_203() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[77], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void miscellaneous_204() 
    {
      Data.executeTest(Data.InconsistencyTests_etc2[78], "etc2-results-net.n3", "InconsistencyTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

  }
}
