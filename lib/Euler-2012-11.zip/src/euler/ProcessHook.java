package euler;

import java.io.*;

public class ProcessHook extends Thread {

	Process pr = null;

	public ProcessHook(Process p) {
		pr = p;
	}

	public void run() {
		pr.stop();
	}
}
