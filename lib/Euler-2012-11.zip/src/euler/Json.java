package euler;

import java.io.*;
import java.util.*;
import org.json.*;

public class Json {
	/**
	 * Main method invoked via <code>java euler.Json</code>
	 * 
	 * @param args
	 *            cases
	 */
	public static void main(String[] args) {
		if (args.length == 0) {
			System.err.println("Usage: java [-Dhttp_proxy=%http_proxy%] euler.Json cases");
		} else {
			try {
				PrintStream out = System.out;
				out.println(getTriples(args[0]));
				if (out != System.out)
					out.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static String getTriples(String in) {
		try {
			String js = new Euler().fromWeb(in);
			JSONObject j = new JSONObject(js);
			StringBuffer sb = new StringBuffer();
			JSONObject jg = (JSONObject) j.get("GND");
			Iterator keys = jg.keys();
			while (keys.hasNext()) {
				String o = (String) keys.next();
				sb.append("@prefix ").append(o).append(" <").append(jg.get(o)).append(">.\n");
			}
			sb.append('\n');
			keys = j.keys();
			while (keys.hasNext()) {
				String o = (String) keys.next();
				if (o.equals("GND"))
					continue;
				if (o.equals(""))
					continue;
				JSONArray jc = (JSONArray) j.get(o);
				for (int i = 0; i < jc.length(); i++) {
					JSONObject jh = (JSONObject) ((JSONObject) jc.get(i)).get("head");
					JSONArray jb = (JSONArray) ((JSONObject) jc.get(i)).get("body");
					if (jb.length() != 0 && !((String) ((JSONObject) jb.get(0)).get("pred")).equals("GND")) {
						sb.append('{');
						JSONArray ji = jb;
						for (int ii = 0; ii < ji.length(); ii++) {
							JSONObject jf = (JSONObject) ji.get(ii);
							String pred = (String) jf.get("pred");
							String subj = getThing((JSONObject) ((JSONArray) jf.get("args")).get(0));
							String obj = getThing((JSONObject) ((JSONArray) jf.get("args")).get(1));
							if (sb.charAt(sb.length() - 1) != '{')
								sb.append(". ");
							sb.append(subj).append(' ').append(pred).append(' ').append(obj);
						}
						sb.append("} => {");
						String pred = (String) jh.get("pred");
						String subj = getThing((JSONObject) ((JSONArray) jh.get("args")).get(0));
						String obj = getThing((JSONObject) ((JSONArray) jh.get("args")).get(1));
						sb.append(subj).append(' ').append(pred).append(' ').append(obj);
						sb.append("}.\n");
					} else {
						String pred = (String) jh.get("pred");
						String subj = getThing((JSONObject) ((JSONArray) jh.get("args")).get(0));
						String obj = getThing((JSONObject) ((JSONArray) jh.get("args")).get(1));
						sb.append(subj).append(' ').append(pred).append(' ').append(obj);
						sb.append(".\n");
					}
				}
			}
			return sb.toString();
		} catch (Exception exc) {
			throw new RuntimeException(exc);
		}
	}

	public static String getThing(JSONObject j) {
		try {
			String h = (String) j.get("pred");
			StringBuffer sb = new StringBuffer();
			if (h.equals("")) {
				sb.append('{');
				JSONArray jc = (JSONArray) j.get("args");
				for (int i = 0; i < jc.length(); i++) {
					JSONObject jf = (JSONObject) jc.get(i);
					String pred = (String) jf.get("pred");
					String subj = getThing((JSONObject) ((JSONArray) jf.get("args")).get(0));
					String obj = getThing((JSONObject) ((JSONArray) jf.get("args")).get(1));
					if (sb.charAt(sb.length() - 1) != '{')
						sb.append(". ");
					sb.append(subj).append(' ').append(pred).append(' ').append(obj);
				}
				sb.append('}');
			} else if (h.equals(".")) {
				sb.append('(');
				JSONObject ji = j;
				while (((JSONArray) ji.get("args")).length() != 0) {
					if (sb.charAt(sb.length() - 1) != '(')
						sb.append(' ');
					sb.append(getThing((JSONObject) ((JSONArray) ji.get("args")).get(0)));
					ji = (JSONObject) ((JSONArray) ji.get("args")).get(1);
				}
				sb.append(')');
			} else if (h.equals("^"))
				sb.append(getThing((JSONObject) ((JSONArray) j.get("args")).get(0))).append("^").append(
						getThing((JSONObject) ((JSONArray) j.get("args")).get(1)));
			else if (h.equals("!"))
				sb.append(getThing((JSONObject) ((JSONArray) j.get("args")).get(0))).append("!").append(
						getThing((JSONObject) ((JSONArray) j.get("args")).get(1)));
			else if (h.equals("^^"))
				sb.append(getThing((JSONObject) ((JSONArray) j.get("args")).get(0))).append("^^").append(
						getThing((JSONObject) ((JSONArray) j.get("args")).get(1)));
			else
				sb.append(h);
			return sb.toString();
		} catch (Exception exc) {
			throw new RuntimeException(exc);
		}
	}
}
