// $Id: NegativeEntailmentTest_etc1.java 1537 2007-09-20 21:42:34Z josd $

package euler.test;

import java.io.File;

// imports from junit.jar
import junit.framework.TestCase;

public class NegativeEntailmentTest_etc1 extends TestCase {

	/* ***************************************************************** */
	/* ** START : Constructor */
	/* ***************************************************************** */

	public NegativeEntailmentTest_etc1(String s) {
		super(s);
	}

	/* ***************************************************************** */
	/* ** END : Constructor */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : protected methods */
	/* ***************************************************************** */

	protected void setUp() {
	}

	protected void tearDown() {
		File f = new File("test.n3");
		f.delete();
	}

	/* ***************************************************************** */
	/* ** END : protected methods */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : test cases */
	/* ***************************************************************** */

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_datatypesintensional_xsdintegerdecimalcompatible() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[0], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_datatypes_nonwellformedliteral2() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[1], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_datatypes_test009() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[2], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_horst01_subClassOfintensional() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[3], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_horst01_subPropertyOfintensional() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[4], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_rdfcharmoduris_test003() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[5], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_rdfcharmoduris_test004() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[6], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_rdfmsxmllang_test007a() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[7], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_rdfmsxmllang_test007b() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[8], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_rdfmsxmllang_test007c() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[9], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_rdfscontainermembershipsuperProperty_test001() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[10], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_rdfsdomainandrange_intensionalitydomain() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[11], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_rdfsdomainandrange_intensionalityrange() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[12], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_rdfssubClassOfaProperty_test001() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[13], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_statemententailment_test001() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[14], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_statemententailment_test002() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[15], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_statemententailment_test003() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[16], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_statemententailment_test004() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[17], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_xmlsch02_whitespacefacet1() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[18], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_xmlsch02_whitespacefacet2() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[19], this, "etc1-results-java.n3");
	}

	public void test_NegativeEntailmentTest_etc1_rdftests_rdfcore_xmlsch02_whitespacefacet4() {
		Data.executeTest(Data.NegativeEntailmentTests_etc1[20], this, "etc1-results-java.n3");
	}

	/* ***************************************************************** */
	/* ** END : test cases */
	/* ***************************************************************** */
}
