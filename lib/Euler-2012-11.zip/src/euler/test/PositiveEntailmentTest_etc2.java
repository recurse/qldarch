// $Id: PositiveEntailmentTest_etc2.java 1537 2007-09-20 21:42:34Z josd $

package euler.test;

import java.io.File;

// imports from junit.jar
import junit.framework.TestCase;

public class PositiveEntailmentTest_etc2 extends TestCase {

	/* ***************************************************************** */
	/* ** START : Constructor */
	/* ***************************************************************** */

	public PositiveEntailmentTest_etc2(String s) {
		super(s);
	}

	/* ***************************************************************** */
	/* ** END : Constructor */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : protected methods */
	/* ***************************************************************** */

	protected void setUp() {
	}

	protected void tearDown() {
		File f = new File("test.n3");
		f.delete();
	}

	/* ***************************************************************** */
	/* ** END : protected methods */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : test cases */
	/* ***************************************************************** */

	public void test_PositiveEntailmentTest_etc2_AllDifferent_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[0], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_AnnotationProperty_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[1], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_Class_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[2], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_Class_003() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[3], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_Class_006() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[4], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_FunctionalProperty_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[5], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_FunctionalProperty_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[6], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_FunctionalProperty_003() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[7], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_FunctionalProperty_004() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[8], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_FunctionalProperty_005() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[9], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I4_5_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[10], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I4_6_003() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[11], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_1_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[12], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_2_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[13], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_2_004() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[14], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_2_006() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[15], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_21_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[16], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_24_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[17], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_24_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[18], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_24_003() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[19], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_24_004() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[20], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_26_009() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[21], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_26_010() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[22], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_3_014() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[23], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_3_015() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[24], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_5_005() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[25], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_8_004() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[26], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_8_006() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[27], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_8_008() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[28], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_8_009() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[29], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_8_010() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[30], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_I5_8_017() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[31], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_InverseFunctionalProperty_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[32], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_InverseFunctionalProperty_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[33], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_InverseFunctionalProperty_003() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[34], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_InverseFunctionalProperty_004() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[35], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_Ontology_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[36], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_Ontology_004() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[37], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_Restriction_006() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[38], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_SymmetricProperty_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[39], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_SymmetricProperty_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[40], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_SymmetricProperty_003() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[41], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_TransitiveProperty_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[42], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_TransitiveProperty_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[43], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_allValuesFrom_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[44], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_cardinality_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[45], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_cardinality_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[46], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_cardinality_003() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[47], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_cardinality_004() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[48], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_cardinality_006() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[49], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_complementOf_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[50], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_201() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[51], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_202() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[52], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_203() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[53], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_204() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[54], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_205() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[55], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_206() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[56], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_207() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[57], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_208() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[58], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_661() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[59], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_662() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[60], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_663() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[61], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_664() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[62], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_665() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[63], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_667() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[64], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_901() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[65], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_description_logic_903() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[66], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_differentFrom_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[67], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_differentFrom_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[68], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_disjointWith_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[69], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_disjointWith_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[70], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_distinctMembers_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[71], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_equivalentClass_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[72], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_equivalentClass_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[73], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_equivalentClass_003() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[74], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_equivalentClass_004() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[75], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_equivalentClass_006() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[76], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_equivalentClass_007() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[77], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_equivalentProperty_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[78], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_equivalentProperty_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[79], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_equivalentProperty_003() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[80], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_equivalentProperty_004() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[81], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_equivalentProperty_005() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[82], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_equivalentProperty_006() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[83], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_extra_credit_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[84], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_extra_credit_003() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[85], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_extra_credit_004() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[86], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_intersectionOf_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[87], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_inverseOf_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[88], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_miscellaneous_010() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[89], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_miscellaneous_011() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[90], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_oneOf_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[91], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_oneOf_003() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[92], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_oneOf_004() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[93], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_sameAs_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[94], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_someValuesFrom_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[95], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_someValuesFrom_003() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[96], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_unionOf_001() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[97], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_unionOf_002() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[98], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_unionOf_003() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[99], this, "etc2-results-java.n3");
	}

	public void test_PositiveEntailmentTest_etc2_unionOf_004() {
		Data.executeTest(Data.PositiveEntailmentTests_etc2[100], this, "etc2-results-java.n3");
	}

	/* ***************************************************************** */
	/* ** END : test cases */
	/* ***************************************************************** */
}
