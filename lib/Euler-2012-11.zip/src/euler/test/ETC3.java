// $Id: ETC3.java 1537 2007-09-20 21:42:34Z josd $

package euler.test;

import java.io.File;

// imports from junit.jar
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class ETC3 extends TestCase {

	/* ***************************************************************** */
	/* ** START : Constructor */
	/* ***************************************************************** */

	public ETC3(String s) {
		super(s);
	}

	/* ***************************************************************** */
	/* ** END : Constructor */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : public static methods */
	/* ***************************************************************** */

	public static Test suite() {
		TestSuite suite = new TestSuite();
		suite.addTestSuite(euler.test.ETC3.class);
		Outputter.getInstance().initialize("etc3-results-java.n3");
		return suite;
	}

	/* ***************************************************************** */
	/* ** END : public static methods */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : protected methods */
	/* ***************************************************************** */

	protected void setUp() {
	}

	protected void tearDown() {
		File f = new File("test.n3");
		f.delete();
	}

	/* ***************************************************************** */
	/* ** END : protected methods */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : test cases */
	/* ***************************************************************** */

	public void test_ETC3_euler_authen_axiom() {
		Data.executeTest(Data.etc3[0], this, "etc3-results-java.n3");
	}

	public void test_ETC3_euler_graph_axiom() {
		Data.executeTest(Data.etc3[1], this, "etc3-results-java.n3");
	}

	public void test_ETC3_euler_gedcom_relations() {
		Data.executeTest(Data.etc3[2], this, "etc3-results-java.n3");
	}

	public void test_ETC3_euler_danc() {
		Data.executeTest(Data.etc3[3], this, "etc3-results-java.n3");
	}

	public void test_ETC3_euler_ziv() {
		Data.executeTest(Data.etc3[4], this, "etc3-results-java.n3");
	}

	public void test_ETC3_euler_danb() {
		Data.executeTest(Data.etc3[5], this, "etc3-results-java.n3");
	}

	public void test_ETC3_euler_test() {
		Data.executeTest(Data.etc3[6], this, "etc3-results-java.n3");
	}

	public void test_ETC3_euler_animal() {
		Data.executeTest(Data.etc3[7], this, "etc3-results-java.n3");
	}

	public void test_ETC3_euler_subprop() {
		Data.executeTest(Data.etc3[8], this, "etc3-results-java.n3");
	}

	public void test_ETC3_euler_subclass() {
		Data.executeTest(Data.etc3[9], this, "etc3-results-java.n3");
	}

	public void test_ETC3_euler_rdfsfacts() {
		Data.executeTest(Data.etc3[10], this, "etc3-results-java.n3");
	}

	public void test_ETC3_euler_owlfacts() {
		Data.executeTest(Data.etc3[11], this, "etc3-results-java.n3");
	}

	public void test_ETC3_euler_builtins() {
		Data.executeTest(Data.etc3[12], this, "etc3-results-java.n3");
	}

	public void test_ETC3_rdftests_rdfcore_entailment_etc001() {
		Data.executeTest(Data.etc3[13], this, "etc3-results-java.n3");
	}

	public void test_ETC3_RGML_N3_rgml_rules() {
		Data.executeTest(Data.etc3[14], this, "etc3-results-java.n3");
	}

	public void test_ETC3_08swws67_poolGamekb() {
		Data.executeTest(Data.etc3[15], this, "etc3-results-java.n3");
	}

	public void test_ETC3_2000_10_swap_test_pathCross() {
		Data.executeTest(Data.etc3[16], this, "etc3-results-java.n3");
	}

	public void test_ETC3_euler_dtP() {
		Data.executeTest(Data.etc3[17], this, "etc3-results-java.n3");
	}

	public void test_ETC3_2002_10_medicad_op_lldmD() {
		Data.executeTest(Data.etc3[18], this, "etc3-results-java.n3");
	}

	public void test_ETC3_eulersharp_pimP() {
		Data.executeTest(Data.etc3[19], this, "etc3-results-java.n3");
	}

	public void test_ETC3_euler_logfacts() {
		Data.executeTest(Data.etc3[20], this, "etc3-results-java.n3");
	}

	public void test_ETC3_euler_easterP() {
		Data.executeTest(Data.etc3[21], this, "etc3-results-java.n3");
	}

	public void test_ETC3_eulersharp_continentsP() {
		Data.executeTest(Data.etc3[22], this, "etc3-results-java.n3");
	}

	public void test_ETC3_rdftests_rdfcore_ntriples_test() {
		Data.executeTest(Data.etc3[23], this, "etc3-results-java.n3");
	}

	public void test_ETC3_03owlt_mapInvP() {
		Data.executeTest(Data.etc3[24], this, "etc3-results-java.n3");
	}

	public void test_ETC3_03owlt_mapVocabP() {
		Data.executeTest(Data.etc3[25], this, "etc3-results-java.n3");
	}

	public void test_ETC3_03owlt_oneOfP() {
		Data.executeTest(Data.etc3[26], this, "etc3-results-java.n3");
	}

	public void test_ETC3_03owlt_pathTransitiveP() {
		Data.executeTest(Data.etc3[27], this, "etc3-results-java.n3");
	}

	public void test_ETC3_03owlt_unionOfP() {
		Data.executeTest(Data.etc3[28], this, "etc3-results-java.n3");
	}

	public void test_ETC3_03owlt_sameGuyP() {
		Data.executeTest(Data.etc3[29], this, "etc3-results-java.n3");
	}

	public void test_ETC3_03owlt_sameStateP() {
		Data.executeTest(Data.etc3[30], this, "etc3-results-java.n3");
	}

	public void test_ETC3_03owlt_dbP() {
		Data.executeTest(Data.etc3[31], this, "etc3-results-java.n3");
	}

	public void test_ETC3_03owlt_intersectionOfP() {
		Data.executeTest(Data.etc3[32], this, "etc3-results-java.n3");
	}

	public void test_ETC3_03owlt_SocratesP() {
		Data.executeTest(Data.etc3[33], this, "etc3-results-java.n3");
	}

	/* ***************************************************************** */
	/* ** END : test cases */
	/* ***************************************************************** */
}
