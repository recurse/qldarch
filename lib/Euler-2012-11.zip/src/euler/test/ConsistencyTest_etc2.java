// $Id: ConsistencyTest_etc2.java 1537 2007-09-20 21:42:34Z josd $

package euler.test;

import java.io.File;

// imports from junit.jar
import junit.framework.TestCase;

public class ConsistencyTest_etc2 extends TestCase {

	/* ***************************************************************** */
	/* ** START : Constructor */
	/* ***************************************************************** */

	public ConsistencyTest_etc2(String s) {
		super(s);
	}

	/* ***************************************************************** */
	/* ** END : Constructor */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : protected methods */
	/* ***************************************************************** */

	protected void setUp() {
	}

	protected void tearDown() {
		File f = new File("test.n3");
		f.delete();
	}

	/* ***************************************************************** */
	/* ** END : protected methods */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : test cases */
	/* ***************************************************************** */

	public void test_ConsistencyTest_etc2_AnnotationProperty_003() {
		Data.executeTest(Data.ConsistencyTests_etc2[0], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_AnnotationProperty_004() {
		Data.executeTest(Data.ConsistencyTests_etc2[1], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_DatatypeProperty_001() {
		Data.executeTest(Data.ConsistencyTests_etc2[2], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_1_010() {
		Data.executeTest(Data.ConsistencyTests_etc2[3], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_2_001() {
		Data.executeTest(Data.ConsistencyTests_etc2[4], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_2_003() {
		Data.executeTest(Data.ConsistencyTests_etc2[5], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_2_005() {
		Data.executeTest(Data.ConsistencyTests_etc2[6], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_2_010() {
		Data.executeTest(Data.ConsistencyTests_etc2[7], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_2_011() {
		Data.executeTest(Data.ConsistencyTests_etc2[8], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_26_001() {
		Data.executeTest(Data.ConsistencyTests_etc2[9], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_26_002() {
		Data.executeTest(Data.ConsistencyTests_etc2[10], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_26_003() {
		Data.executeTest(Data.ConsistencyTests_etc2[11], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_26_004() {
		Data.executeTest(Data.ConsistencyTests_etc2[12], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_26_005() {
		Data.executeTest(Data.ConsistencyTests_etc2[13], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_26_006() {
		Data.executeTest(Data.ConsistencyTests_etc2[14], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_26_007() {
		Data.executeTest(Data.ConsistencyTests_etc2[15], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_3_005() {
		Data.executeTest(Data.ConsistencyTests_etc2[16], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_3_006() {
		Data.executeTest(Data.ConsistencyTests_etc2[17], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_3_007() {
		Data.executeTest(Data.ConsistencyTests_etc2[18], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_3_008() {
		Data.executeTest(Data.ConsistencyTests_etc2[19], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_3_009() {
		Data.executeTest(Data.ConsistencyTests_etc2[20], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_3_010() {
		Data.executeTest(Data.ConsistencyTests_etc2[21], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_3_011() {
		Data.executeTest(Data.ConsistencyTests_etc2[22], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_8_002() {
		Data.executeTest(Data.ConsistencyTests_etc2[23], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_8_012() {
		Data.executeTest(Data.ConsistencyTests_etc2[24], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_8_013() {
		Data.executeTest(Data.ConsistencyTests_etc2[25], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_8_014() {
		Data.executeTest(Data.ConsistencyTests_etc2[26], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_8_015() {
		Data.executeTest(Data.ConsistencyTests_etc2[27], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I5_8_016() {
		Data.executeTest(Data.ConsistencyTests_etc2[28], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_I6_1_001() {
		Data.executeTest(Data.ConsistencyTests_etc2[29], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_Restriction_003() {
		Data.executeTest(Data.ConsistencyTests_etc2[30], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_Restriction_004() {
		Data.executeTest(Data.ConsistencyTests_etc2[31], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_Thing_004() {
		Data.executeTest(Data.ConsistencyTests_etc2[32], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_backwardCompatibleWith_001() {
		Data.executeTest(Data.ConsistencyTests_etc2[33], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_backwardCompatibleWith_002() {
		Data.executeTest(Data.ConsistencyTests_etc2[34], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_005() {
		Data.executeTest(Data.ConsistencyTests_etc2[35], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_006() {
		Data.executeTest(Data.ConsistencyTests_etc2[36], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_009() {
		Data.executeTest(Data.ConsistencyTests_etc2[37], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_016() {
		Data.executeTest(Data.ConsistencyTests_etc2[38], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_018() {
		Data.executeTest(Data.ConsistencyTests_etc2[39], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_020() {
		Data.executeTest(Data.ConsistencyTests_etc2[40], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_021() {
		Data.executeTest(Data.ConsistencyTests_etc2[41], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_024() {
		Data.executeTest(Data.ConsistencyTests_etc2[42], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_025() {
		Data.executeTest(Data.ConsistencyTests_etc2[43], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_028() {
		Data.executeTest(Data.ConsistencyTests_etc2[44], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_031() {
		Data.executeTest(Data.ConsistencyTests_etc2[45], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_034() {
		Data.executeTest(Data.ConsistencyTests_etc2[46], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_501() {
		Data.executeTest(Data.ConsistencyTests_etc2[47], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_503() {
		Data.executeTest(Data.ConsistencyTests_etc2[48], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_605() {
		Data.executeTest(Data.ConsistencyTests_etc2[49], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_606() {
		Data.executeTest(Data.ConsistencyTests_etc2[50], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_609() {
		Data.executeTest(Data.ConsistencyTests_etc2[51], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_616() {
		Data.executeTest(Data.ConsistencyTests_etc2[52], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_624() {
		Data.executeTest(Data.ConsistencyTests_etc2[53], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_625() {
		Data.executeTest(Data.ConsistencyTests_etc2[54], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_628() {
		Data.executeTest(Data.ConsistencyTests_etc2[55], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_631() {
		Data.executeTest(Data.ConsistencyTests_etc2[56], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_634() {
		Data.executeTest(Data.ConsistencyTests_etc2[57], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_905() {
		Data.executeTest(Data.ConsistencyTests_etc2[58], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_906() {
		Data.executeTest(Data.ConsistencyTests_etc2[59], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_907() {
		Data.executeTest(Data.ConsistencyTests_etc2[60], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_descriptionlogic_908() {
		Data.executeTest(Data.ConsistencyTests_etc2[61], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_disjointWith_003() {
		Data.executeTest(Data.ConsistencyTests_etc2[62], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_disjointWith_004() {
		Data.executeTest(Data.ConsistencyTests_etc2[63], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_disjointWith_005() {
		Data.executeTest(Data.ConsistencyTests_etc2[64], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_disjointWith_006() {
		Data.executeTest(Data.ConsistencyTests_etc2[65], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_disjointWith_007() {
		Data.executeTest(Data.ConsistencyTests_etc2[66], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_disjointWith_008() {
		Data.executeTest(Data.ConsistencyTests_etc2[67], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_disjointWith_009() {
		Data.executeTest(Data.ConsistencyTests_etc2[68], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_equivalentClass_009() {
		Data.executeTest(Data.ConsistencyTests_etc2[69], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_imports_012() {
		Data.executeTest(Data.ConsistencyTests_etc2[70], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_miscellaneous_001() {
		Data.executeTest(Data.ConsistencyTests_etc2[71], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_miscellaneous_002() {
		Data.executeTest(Data.ConsistencyTests_etc2[72], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_miscellaneous_102() {
		Data.executeTest(Data.ConsistencyTests_etc2[73], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_miscellaneous_103() {
		Data.executeTest(Data.ConsistencyTests_etc2[74], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_miscellaneous_201() {
		Data.executeTest(Data.ConsistencyTests_etc2[75], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_miscellaneous_202() {
		Data.executeTest(Data.ConsistencyTests_etc2[76], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_miscellaneous_205() {
		Data.executeTest(Data.ConsistencyTests_etc2[77], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_miscellaneous_303() {
		Data.executeTest(Data.ConsistencyTests_etc2[78], this, "etc2-results-java.n3");
	}

	public void test_ConsistencyTest_etc2_oneOf_001() {
		Data.executeTest(Data.ConsistencyTests_etc2[79], this, "etc2-results-java.n3");
	}

	/* ***************************************************************** */
	/* ***************************************************************** */
	/* ** END : test cases */
	/* ***************************************************************** */
}
