package euler;

import java.io.*;

public class ProcessErr implements Runnable {

	DataInputStream dis = null;
	PrintStream ep = null;
	String err = null;
	boolean running = false;

	public ProcessErr(DataInputStream pe) {
		dis = pe;
	}

	public ProcessErr(DataInputStream pe, PrintStream eps) {
		dis = pe;
		ep = eps;
	}

	public void run() {
		running = true;
		try {
			String co = null;
			while (dis != null && (co = dis.readLine()) != null) {
				if (co.contains("ERROR")) {
					err = co;
				}
				else if (ep != null) {
					ep.println(co);
				}
				else {
					System.err.println(co);
				}
			}
		}
		catch (RuntimeException e) {
			throw e;
		}
		catch (Exception e) {
			System.err.println(e);
		}
		running = false;
	}

	public void start() {
		new Thread(this).start();
	}

	public boolean isRunning() {
		return running;
	}

	public String getError() {
		return err;
	}
}
