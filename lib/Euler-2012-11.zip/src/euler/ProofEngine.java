package euler;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Euler proof engine wrapper
 * 
 * @author Jos De Roo
 */

public class ProofEngine {

	/**
	 * runProofEngine method
	 * 
	 * @param args
	 *      [--no-install] [--swipl] [--yap] &lt;options&gt;* &lt;data&gt;* &lt;query&gt;*
	 * @param ops
	 *      output print stream
	 * @param eps
	 *      error print stream
	 * 
	 * @return the process
	 */
	public static Process runProofEngine(String[] args, PrintStream ops, PrintStream eps) {
		boolean windows = System.getProperty("os.name").startsWith("Windows");
		boolean linux = System.getProperty("os.name").startsWith("Linux");
		boolean install = true;
		boolean swipl = false;
		boolean yap = false;
		for (int i = 0; i < args.length; i++) {
			if (args[i].equals("--no-install")) {
				install = false;
			}
			else if (args[i].equals("--swipl")) {
				swipl = true;
			}
			else if (args[i].equals("--yap")) {
				yap = true;
			}
		}
		String tmpdir = System.getProperty("java.io.tmpdir");
		if (linux) {
			tmpdir = "/tmp/";
		}
		String sep = System.getProperty("file.separator");
		if (!tmpdir.endsWith(sep)) {
			tmpdir += sep;
		}
		if (install) {
			try {
				String jf = ProofEngine.class.getClassLoader().getResource("eye").toString();
				jf = URLDecoder.decode(jf, "UTF-8");
				if (windows) {
					jf = jf.substring(jf.indexOf('/') + 1, jf.lastIndexOf('!'));
				}
				else if (linux) {
					jf = jf.substring(jf.lastIndexOf(':') + 1, jf.lastIndexOf('!'));
				}
				else {
					jf = jf.substring(jf.lastIndexOf(':') + 1, jf.lastIndexOf('!'));
				}
				ZipFile zf = new ZipFile(jf);
				long srcz = zf.getEntry("eye/euler.yap").getTime();
				long srcf = new File(tmpdir + "eye" + sep + "euler.yap").lastModified();
				long binz = 0;
				long binf = 0;
				if (windows) {
					binz = zf.getEntry("eye/windows/bin/yap.exe").getTime();
					binf = new File(tmpdir + "eye\\windows\\bin\\yap.exe").lastModified();
				}
				else if (linux) {
					binz = zf.getEntry("eye/linux/bin/yap").getTime();
					binf = new File(tmpdir + "eye/linux/bin/yap").lastModified();
				}
				if (srcz > srcf || binz > binf) {
					Enumeration entries = zf.entries();
					while (entries.hasMoreElements()) {
						ZipEntry entry = (ZipEntry)entries.nextElement();
						long lm = entry.getTime();
						String n = entry.getName();
						if (n.equals("eye/euler.yap") || windows && n.startsWith("eye/windows") || linux && n.startsWith("eye/linux")) {
							String fn = tmpdir + n;
							String cn = new File(fn).getCanonicalPath();
							String pn = cn.substring(0, cn.lastIndexOf(sep));
							if (!new File(pn).exists()) {
								new File(pn).mkdirs();
							}
							if (entry.isDirectory()) {
								new File(fn).mkdirs();
							}
							else {
								InputStream in = zf.getInputStream(entry);
								OutputStream out = new BufferedOutputStream(new FileOutputStream(fn));
								byte[] buffer = new byte[4096];
								int len;
								while ((len = in.read(buffer)) >= 0)
									out.write(buffer, 0, len);
								in.close();
								out.close();
							}
							new File(fn).setLastModified(lm);
						}
					}
					zf.close();
					if (linux) {
						new File(tmpdir + "eye/linux/bin/yap").setExecutable(true, false);
					}
				}
			}
			catch (IOException e) {
				try {
					System.err.println("Delayed due to " + e);
					Thread.currentThread().sleep(5000);
				}
				catch (Throwable exc) {
					exc.printStackTrace();
				}
			}
			catch (Throwable e) {
				e.printStackTrace();
			}
		}
		long ttl = Long.MAX_VALUE;
		int j;
		String[] cmd;
		if (windows) {
			j = 9;
			cmd = new String[j + args.length];
			cmd[0] = (swipl ? "swipl" : (yap ? "yap" : tmpdir + "eye\\windows\\bin\\yap"));
			cmd[1] = "-q";
			cmd[2] = "-f";
			cmd[3] = tmpdir + "eye\\euler.yap";
			cmd[4] = "-g";
			cmd[5] = "main";
			cmd[6] = "--";
			cmd[7] = "--wget-path";
			cmd[8] = tmpdir + "eye\\windows\\bin\\";
		}
		else if (linux) {
			j = 7;
			cmd = new String[j + args.length];
			cmd[0] = (swipl ? "swipl" : (yap ? "yap" : tmpdir + "eye/linux/bin/yap"));
			cmd[1] = "-q";
			cmd[2] = "-f";
			cmd[3] = tmpdir + "eye/euler.yap";
			cmd[4] = "-g";
			cmd[5] = "main";
			cmd[6] = "--";
		}
		else {
			j = 7;
			cmd = new String[j + args.length];
			cmd[0] = (swipl ? "swipl" : (yap ? "yap" : "yap"));
			cmd[1] = "-q";
			cmd[2] = "-f";
			cmd[3] = tmpdir + "eye" + sep + "euler.yap";
			cmd[4] = "-g";
			cmd[5] = "main";
			cmd[6] = "--";
		}
		ArrayList<File> fs = new ArrayList<File>();
		for (int i = 0; i < args.length; i++) {
			if (args[i].startsWith("http://localhost/.context")) {
				try {
					File f = File.createTempFile("eye_", ".n3");
					fs.add(f);
					FileOutputStream fos = new FileOutputStream(f);
					OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF8");
					osw.write(Codd.urlDecode(args[i]).substring(26));
					osw.flush();
					osw.close();
					cmd[j++] = f.getAbsolutePath();
				}
				catch (Throwable t) {
					t.printStackTrace();
				}
			}
			else {
				cmd[j++] = args[i];
			}
		}
		Runtime rt = Runtime.getRuntime();
		Process pr = new Process(cmd, null, ops, eps);
		ProcessHook ph = new ProcessHook(pr);
		rt.addShutdownHook(ph);
		int ev = pr.execute(ttl);
		rt.removeShutdownHook(ph);
		if (ev != 0) {
			throw new RuntimeException("Abnormal process termination");
		}
		for (File f : fs)
			f.delete();
		return pr;
	}

	/**
	 * runProofEngine method
	 * 
	 * @param args
	 *      &lt;options&gt;* &lt;data&gt;* &lt;query&gt;*
	 * 
	 * @return the proof
	 */
	public static String runProofEngine(String[] args) {
		Process pr = runProofEngine(args, null, System.err);
		return pr.getOutput();
	}

	/**
	 * main method
	 * 
	 * @param args
	 *      &lt;options&gt;* &lt;data&gt;* &lt;query&gt;*
	 */
	public static void main(String[] args) {
		try {
			PrintStream ps = new PrintStream(System.out, true, "UTF8");
			runProofEngine(args, ps, System.err);
		}
		catch (Throwable e) {
			e.printStackTrace();
		}
	}
}
