package euler;

public class Stack {

	private int max = 4096;
	private int top = 0;
	private Euler[] ea = new Euler[max];
	private int[] ia = new int[max];
	private Euler w = new Euler();

	/**
	 * This method pushes an element on the stack
	 * 
	 * @param e
	 *                euler object
	 * @param i
	 */
	final void push(Euler e, int i) {
		ea[top] = e;
		ia[top++] = i;
		if (top == max) {
			Euler[] ea_ = ea;
			int[] ia_ = ia;
			int max_ = max;
			max = max * 2;
			ea = new Euler[max];
			ia = new int[max];
			System.arraycopy(ea_, 0, ea, 0, max_);
			System.arraycopy(ia_, 0, ia, 0, max_);
		}
	}

	/**
	 * This method pops an element from the stack
	 * 
	 * @return the top element of the stack
	 */
	final Euler pop() {
		if (top == 0)
			return null;
		if (ea[--top] == null) {
			w.varid = ia[top];
			return w;
		} else
			return ea[top];
	}
}
